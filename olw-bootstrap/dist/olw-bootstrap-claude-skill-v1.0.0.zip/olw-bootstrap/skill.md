# OLW Bootstrap Skill

## Description
Automatically generates a comprehensive Operational Language Wiki (OLW) system from domain knowledge and institutional context. Creates interconnected wiki pages following the WikiPage v1 specification with proper cross-linking, aliases, and structured sections.

## Usage
Use this skill when you need to:
- Build a complete wiki system from scratch based on domain knowledge
- Document institutional terminology and operational concepts
- Create interconnected knowledge bases with semantic search support
- Transform system instructions or domain documentation into structured wiki pages

## Input Required
- **Domain Context**: Either a path to configuration/documentation files OR direct description of the domain
- **Output Directory**: Path to the wiki metadata directory (typically `globals/metadata/wiki/`)

## What This Skill Does
1. Analyzes domain knowledge and institutional context
2. Identifies key concepts, terminology, and relationships
3. Creates a comprehensive set of wiki pages covering:
   - Core entities and concepts
   - Business processes and operations
   - Metrics and measurements
   - Products and services
   - Strategic initiatives
   - Operational rules and assumptions
4. Establishes wiki:// cross-links between related concepts
5. Adds aliases for searchability
6. Structures content with definitions, details, and sections
7. Ensures semantic coherence across the wiki system

## Output
- Multiple YAML files (one per concept) in WikiPage v1 format
- Proper cross-linking using wiki:// protocol
- Comprehensive coverage of domain concepts
- Ready for semantic AI-powered search

## Example Invocation
```
Use the olw-bootstrap skill to create a wiki system from the domain context in globals/metadata/promptql-config.hml, outputting to globals/metadata/wiki/
```

## Notes
- The skill will create 15-25 wiki pages depending on domain complexity
- Each page follows WikiPage v1 specification
- Cross-links are automatically identified and created
- Aliases improve semantic search effectiveness
